package com.cogent.boot.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Plans {
	//productname,cost ,date of purchase,deliveey date,feedback of customer
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String planName;
	private double cost;
	private boolean validity;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public boolean isValidity() {
		return validity;
	}
	public void setValidity(boolean validity) {
		this.validity = validity;
	}
	
	@Override
	public String toString() {
		return "Plans [id=" + id + ", planName=" + planName + ", cost=" + cost + ", validity=" + validity + "]";
	}
	
}