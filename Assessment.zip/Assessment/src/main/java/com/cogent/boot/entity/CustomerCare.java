package com.cogent.boot.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class CustomerCare {
	//productname,cost ,date of purchase,deliveey date,feedback of customer
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String complaintDescription;
	private int userId;
	private String complaintStatus;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getComplaintDescription() {
		return complaintDescription;
	}
	public void setComplaintDescription(String complaintDescription) {
		this.complaintDescription = complaintDescription;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getComplaintStatus() {
		return complaintStatus;
	}
	public void setComplaintStatus(String complaintStatus) {
		this.complaintStatus = complaintStatus;
	}
	
	@Override
	public String toString() {
		return "CustomerCare [id=" + id + ", complaintDescription=" + complaintDescription + ", userId=" + userId
				+ ", complaintStatus=" + complaintStatus + "]";
	}
	
}
