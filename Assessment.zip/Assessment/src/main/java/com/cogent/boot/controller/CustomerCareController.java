package com.cogent.boot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cogent.boot.entity.CustomerCare;
import com.cogent.boot.repo.CustomerCareRepo;

@RestController
public class CustomerCareController {

	@Autowired
	CustomerCareRepo customerCareRepo;

	@PostMapping("/addcustomercare")
	CustomerCare newCustomerCare(@RequestBody CustomerCare customerCare) {
		return customerCareRepo.save(customerCare); // SQL INSERT INTO DB
	}

	@GetMapping("/getcustomercare") // End Point
	List<CustomerCare> getAllCustomerCares() {
		return customerCareRepo.findAll();
	}
}
