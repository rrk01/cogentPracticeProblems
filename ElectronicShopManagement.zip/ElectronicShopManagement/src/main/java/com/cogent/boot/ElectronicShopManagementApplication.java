package com.cogent.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectronicShopManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectronicShopManagementApplication.class, args);
	}

}
