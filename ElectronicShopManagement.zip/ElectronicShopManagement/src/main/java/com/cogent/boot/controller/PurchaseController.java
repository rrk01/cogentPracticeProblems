package com.cogent.boot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cogent.boot.entity.Purchase;
import com.cogent.boot.repo.PurchaseRepository;

@RestController
public class PurchaseController {
	
	@Autowired
	PurchaseRepository purchaseRepo;
	
	@PostMapping("/addpurchase")
	Purchase newEmployee(@RequestBody Purchase purchase) {
		return purchaseRepo.save(purchase); // insert SQL
	}
	
	@GetMapping("/getpurchase") // End Point
	// @RequestMapping(method=RequestMethod.GET ,value="/users")
	List<Purchase> getAllPurchases() {
		return purchaseRepo.findAll();
	}
	
	@DeleteMapping("/deletepurchase/{id}")
	String deleteEmployee(@PathVariable("id") int id) {
		try {
			purchaseRepo.deleteById(id);
			return "Deletion successful.";
		}catch(Exception e) {
			e.printStackTrace();
			return "Deletion unsuccessful.";
		}
	}

}
